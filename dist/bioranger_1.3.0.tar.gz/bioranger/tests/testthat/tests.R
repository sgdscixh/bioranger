# Generated from create-bioranger.Rmd: do not edit by hand
testthat::test_that("say_hello works", {
  testthat::expect_equal(2 * 2, 4) # 期待2*2 = 4 ha
})
